/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 *
 * @author hussam
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface GetTime 
{
    @WebMethod(operationName = "Time")
    @WebResult(partName = "time_Res")
    public String getTime();
    
    @WebMethod
    @Oneway
    public void Hello(String Name);
}
