/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;

/**
 *
 * @author hussam
 */
public class Consumer {

    public static void main(String[] args) {
    
        try 
        {
            URL url = new URL("http://127.0.0.1:9090/ts?wsdl");
            QName qName = new QName("http://WS.hussam.net/", "GetTimeImpService");
            Service service = Service.create(url, qName);
            GetTime TimeService = service.getPort(GetTime.class);
            BindingProvider bindProv = (BindingProvider) TimeService;
            List<Handler> handlers = bindProv.getBinding().getHandlerChain();
            handlers.add(new MyServiceLogHandler());
            bindProv.getBinding().setHandlerChain(handlers);
            String Country="Egypt";
            Holder<String> Date = new Holder<>(Country); 
            TimeService.Hello("Hussam");
            String time = TimeService.getTime();
            System.out.println(Date.value + " " +time);
        } catch (MalformedURLException ex) {
        }
    }

}
