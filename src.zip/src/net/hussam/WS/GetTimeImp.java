/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS;

import java.util.Date;
import javax.jws.WebService;

/**
 *
 * @author hussam
 */
@WebService(endpointInterface = "net.hussam.WS.GetTime")
public class GetTimeImp implements GetTime{

    
    
    @Override
    public String getTime() 
    {
        return new Date().toString();
    }

    @Override
    public void Hello(String Name) {
        System.out.println("Hello "+Name);
    }

}
