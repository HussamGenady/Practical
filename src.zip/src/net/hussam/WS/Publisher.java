/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS;

import javax.xml.ws.Endpoint;
import net.hussam.WS_JMS.ComputerHandler;
import net.hussam.WS_JMS.ComputerImp;

/**
 *
 * @author hussam
 */
public class Publisher
{
    public static void main(String[] args) {
        ComputerHandler sib=new ComputerHandler();
        Endpoint.publish("http://127.0.0.1:9090/jms", sib);
    }
}
