/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Mock;

import java.util.ArrayList;
import java.util.List;
import org.easymock.EasyMock;


public class PortfolioTester {
   public static void main(String[] args){

      //Create a portfolio object which is to be tested		
      Portfolio portfolio = new Portfolio();

      //Creates a list of stocks to be added to the portfolio
      List stocks = new ArrayList();
      Stock googleStock = new Stock("1","Google", 10);
      Stock microsoftStock = new Stock("2","Microsoft",100);

      stocks.add(googleStock);
      stocks.add(microsoftStock);		

      //Create the mock object of stock service
      StockService stockServiceMock = EasyMock.createMock(StockService.class);

      // mock the behavior of stock service to return the value of various stocks
      EasyMock.expect(stockServiceMock.getPrice(googleStock)).andReturn(50.00);
      EasyMock.expect(stockServiceMock.getPrice(microsoftStock)).andReturn(1000.00);

      EasyMock.replay(stockServiceMock);

      //add stocks to the portfolio
      portfolio.setStocks(stocks);

      //set the stockService to the portfolio
      portfolio.setStockService(stockServiceMock);

      double marketValue = portfolio.getMarketValue();

      //verify the market value to be 
      //10*50.00 + 100* 1000.00 = 500.00 + 100000.00 = 100500
      System.out.println("Market value of the portfolio: "+ marketValue);
      EasyMock.verify(stockServiceMock);
   }
}