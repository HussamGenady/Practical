/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Mock;

import java.util.List;

/**
 *
 * @author genady
 */
public class Portfolio {

    StockService stockServiceMock;
    List stocks;

    void setStocks(List stocks) {
        this.stocks = stocks;
    }

    void setStockService(StockService stockServiceMock) {
        this.stockServiceMock = stockServiceMock;
    }

    double getMarketValue() {
        //10*50.00 + 100* 1000.00 = 500.00 + 100000.00 = 100500
        double price = stockServiceMock.getPrice((Stock) stocks.get(0));
        price *= 10;
        double price1=stockServiceMock.getPrice((Stock) stocks.get(1));
        price1*=100;
       
        return price+price1;
    }

}
