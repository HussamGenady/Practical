/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_REST;

import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;

/**
 *
 * @author hussam
 */
public class DispatcherClient
{
    public DispatcherClient() throws IOException
    {
        try 
        {
            URI address = new URI("http://127.0.0.1:8080/grt");
            Connect(address.toString(),null);
        } catch (URISyntaxException ex) {}
    }

    public void Connect(String endpoint,Source Req)
    {
        QName service_name = new QName("", ""); // uri is urn:fib
        QName port = new QName("", "");
        
        
        Service service = Service.create(service_name);
        service.addPort(port, HTTPBinding.HTTP_BINDING, endpoint);
        Dispatch<Source> dispatch = service.createDispatch(port, Source.class, Service.Mode.PAYLOAD);
        
        Map<String, Object> request_context = dispatch.getRequestContext();
        request_context.put(MessageContext.HTTP_REQUEST_METHOD, "GET");
        
        StreamSource result = (StreamSource) dispatch.invoke(Req);
        
        ShowResponse(result);
    }
    
    public StreamSource getRequest()
    {
        ByteArrayOutputStream Req=new ByteArrayOutputStream();
        
        try (XMLEncoder encoder = new XMLEncoder(Req)) {
            encoder.writeObject("Hussam");
            encoder.flush();
        }

        StreamSource Param = new StreamSource(new ByteArrayInputStream(Req.toByteArray()));
        return Param;
    }
   
    public void ShowResponse(StreamSource result)
    {
        try {
//            DOMResult dom_result = new DOMResult();
//            Transformer trans = TransformerFactory.newInstance().newTransformer();
//            trans.transform(result, dom_result);
//            XPathFactory xpf = XPathFactory.newInstance();
//            XPath xp = xpf.newXPath();
//            xp.setNamespaceContext(new NSResolver());
//            String Res = xp.evaluate("/dwml/data/parameters/temperature/value", dom_result.getNode());
            InputStreamReader reader=new InputStreamReader(result.getInputStream());
            char[] Res=new char[50000];
            reader.read(Res);
            System.out.println(String.valueOf(Res).trim());
        } catch (/*TransformerException|XPathExpressionException*/IOException ex) {
            Logger.getLogger(DispatcherClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {
        try {
            DispatcherClient c=new DispatcherClient();
        } catch (IOException ex) {
            Logger.getLogger(DispatcherClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static class NSResolver implements NamespaceContext
    {
        private Map<String, String> prefix2uri;
        private Map<String, String> uri2prefix;
        public NSResolver() {
        if (prefix2uri == null) prefix2uri =
        Collections.synchronizedMap(new HashMap<String, String>());
        if (uri2prefix == null) uri2prefix =
        Collections.synchronizedMap(new HashMap<String, String>());
        }
        public NSResolver(String prefix, String uri) 
        {
            this();
            prefix2uri.put(prefix, uri);
            uri2prefix.put(uri, prefix);
        }
        
       @Override
        public String getNamespaceURI(String prefix) { return prefix2uri.get(prefix); }
       @Override
        public String getPrefix(String uri) { return uri2prefix.get(uri); }
       @Override
        public Iterator getPrefixes(String uri) { return uri2prefix.keySet().iterator(); }
    }
}
