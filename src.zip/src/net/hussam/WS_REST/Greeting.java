/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_REST;

import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.LinkedList;
import java.util.Map;
import javax.annotation.Resource;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.BindingType;
import javax.xml.ws.Provider;
import javax.xml.ws.Service;
import javax.xml.ws.ServiceMode;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.WebServiceProvider;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;
import javax.xml.ws.http.HTTPException;

/**
 *
 * @author hussam
 */
@WebServiceProvider
@BindingType(value = HTTPBinding.HTTP_BINDING)
@ServiceMode(Service.Mode.MESSAGE)
public class Greeting implements Provider<Source> 
{

    @Resource
    private WebServiceContext WS_Context;
    private MessageContext msg_ctx;
    private String queryString;
    private String method;

    @Override
    public Source invoke(Source request) 
    {
        msg_ctx=  WS_Context.getMessageContext();
        queryString=(String)msg_ctx.get(MessageContext.QUERY_STRING);
        method = (String) msg_ctx.get(MessageContext.HTTP_REQUEST_METHOD);
        switch(method.toUpperCase())
          {
              case "GET":
              {return doGet();}
              case "POST":
              {return doPost();}
              case "PUT":
              {return doPut();}
              default:
              {return doDelete();}
          }
    }
    
    private Source doGet() 
    {
        System.out.println("In doGet");
        StreamSource Result=new StreamSource();
        if(queryString.equalsIgnoreCase(""))
        {
            throw new HTTPException(400);
        }
        else
        {
            String[] params = queryString.split("&");
            String Val = params[0].split("=")[1];
            System.out.println(Val);
            ByteArrayOutputStream Res=new ByteArrayOutputStream();
            XMLEncoder encoder =new XMLEncoder(Res);
            encoder.writeObject("Hi "+Val);
            encoder.flush();
            encoder.close();
            System.out.println(Res.toString());
            Result = new StreamSource(new ByteArrayInputStream(Res.toByteArray()));
        }
        return Result;
    }
    
    private Source doPost()
    {
        System.out.println("In doPost");
        Map<String,LinkedList> Req=(Map<String,LinkedList>)msg_ctx.get(MessageContext.HTTP_REQUEST_HEADERS);
        LinkedList<String> get = Req.get("Name");
        
        return null;
    }
    
    private Source doPut()
    {
        System.out.println("In doPut");
        return null;
    }
    
    private Source doDelete()
    {
        System.out.println("In doDelete");
        return null;
    }
    
}