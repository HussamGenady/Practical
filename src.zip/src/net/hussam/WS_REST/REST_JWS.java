/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_REST;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

/**
 *
 * @author hussam
 */
@Path(value = "/")
public class REST_JWS 
{
    @GET
    @Produces(value = "text/plain")
    public String Hello()
    {
        return "Hello";
    }
    
    @GET
    @Produces(value = "text/plain")
    public String Hi_User(@PathParam("Name") String Name)
    {
        return "Hi"+Name;
    }
    
    @POST
    @Produces("text/plain")
    public String Hello_User(@FormParam("Name") String Name)
    {
        return "Hello"+Name;
    }
}
