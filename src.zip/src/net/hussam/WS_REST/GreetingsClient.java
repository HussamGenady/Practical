/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_REST;

import java.beans.XMLDecoder;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hussam
 */
public class GreetingsClient 
{
    private HttpURLConnection con;
    private InputStreamReader reader;
    
    public GreetingsClient()
    {
        con=getConnection("http://127.0.0.1:9090/grt?Name=Hussam","GET");
        try 
        {
//            con.setRequestProperty("Name", "Hussam");
            con.connect();
            System.out.println("Connected...");
            PrintRawRes();
        } 
        catch (IOException ex) {}
    }

    private HttpURLConnection getConnection(String Url, String Method) 
    {
        HttpURLConnection Retun=null;
        try 
        {
            URL url=new URL(Url);
            Retun=(HttpURLConnection)url.openConnection();
            Retun.setRequestMethod(Method);
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }
        return Retun;
    }
    
    private void PrintRawRes()
    {
        try 
        {
            reader=new InputStreamReader(con.getInputStream());
            char[] Res=new char[1000];
            reader.read(Res);
            System.out.println(String.valueOf(Res).trim());
        } catch (IOException ex) {}
    }
    
    private void PrintVal()
    {
        try {
            XMLDecoder decoder=new XMLDecoder(con.getInputStream());
            String val=(String) decoder.readObject();
            System.out.println(val);
        } catch (IOException ex) {
            Logger.getLogger(GreetingsClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {
        GreetingsClient client=new GreetingsClient();
    }

}
