/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_REST;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;

/**
 *
 * @author hussam
 */
public class DispatchClient4Soap 
{
    
    public DispatchClient4Soap()
    {
        Connect();
    }

    private void Connect() 
    {
        
        QName service_name = new QName("GetTimeImpService", "http://WS.hussam.net/");
        QName port = new QName("GetTimeImpPort", "http://WS.hussam.net/");
        String endpoint = "http://127.0.0.1:9090/ts";
        Service service = Service.create(service_name);
        service.addPort(port, HTTPBinding.HTTP_BINDING, endpoint);
        Dispatch<Source> dispatch = service.createDispatch(port, Source.class, Service.Mode.PAYLOAD);
        String Req=getSoapReq();
        Map<String, Object> request_context = dispatch.getRequestContext();
        request_context.put(MessageContext.HTTP_REQUEST_METHOD, "POST");
        StreamSource source = make_stream_source(Req);
        System.out.println(Req);
        Source result = dispatch.invoke(source);
        display_result((StreamSource)result, "http://WS.hussam.net/");
    }

    private String getSoapReq() 
    {
        String soap_request =
//        "<?xml version='1.0' encoding='UTF-8'?> " +
        "<soap:Envelope " +
        "soap:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/' " +
        "xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/' " +
        "xmlns:soapenc='http://schemas.xmlsoap.org/soap/encoding/' " +
        "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' " +
        "xmlns:tns='http://WS.hussam.net/' " +
        "xmlns:xsd='http://www.w3.org/2001/XMLSchema'> " +
        "<soap:Body>" +
        "<tns:Time/>" +
        "</soap:Body>" +
        "</soap:Envelope>";
        return soap_request;
    }
    
    private StreamSource make_stream_source(String msg) 
    {
        ByteArrayInputStream stream = new ByteArrayInputStream(msg.getBytes());
        return new StreamSource(stream);
    }

    private void display_result(StreamSource result, String httpWShussamnet) 
    {
        try 
        {
            InputStreamReader reader=new InputStreamReader(result.getInputStream());
            char[] Res=new char[1000];
            reader.read(Res);
            System.out.println(String.valueOf(Res).trim());
        } catch (IOException ex) {}
    }

    public static void main(String[] args) {
        DispatchClient4Soap client=new DispatchClient4Soap();
    }
    
}
