/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hussam
 */
public class Consumer {

    public static void main(String[] args)
    {
        String IDs[]=new String[30];
                
        try 
        {
            URL url = new URL("http://127.0.0.1:9090/jms?wsdl");
            QName qName = new QName("http://WS_JMS.hussam.net/", "ComputerHandlerService");
            Service service = Service.create(url, qName);
            Computer computerSer = service.getPort(Computer.class);
            for(int i=1;i<31;i++)
            {
                String res = computerSer.Fib(i);
                int FibRes = computerSer.FibRes(res);
                System.out.println(res+" => "+FibRes);
            }
        } catch (MalformedURLException ex) {
        }
    }

}
