/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 *
 * @author hussam
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT ,parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)
public interface Computer
{
    @WebMethod(operationName = "Fib")
    @WebResult(partName = "ID")
    public String Fib(@WebParam(name = "param") int param);
    
    @WebMethod(operationName = "FibRes")
    @WebResult(partName = "Result")
    public int FibRes(@WebParam(name = "ID") String ID);
}
