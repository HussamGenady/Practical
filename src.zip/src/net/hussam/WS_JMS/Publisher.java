/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import javax.xml.ws.Endpoint;

/**
 *
 * @author hussam
 */
public class Publisher
{
    public static void main(String[] args) {
        ComputerHandler sib=new ComputerHandler();
        Endpoint endpoint = Endpoint.create(sib);
        endpoint.setExecutor(new ScheduledThreadPoolExecutor(5));
        endpoint.publish("http://127.0.0.1:9090/jms");
    }
}
