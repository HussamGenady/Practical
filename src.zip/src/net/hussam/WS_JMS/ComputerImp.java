/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;

/**
 *
 * @author hussam
 */
@WebService(endpointInterface = "net.hussam.WS_JMS.Computer")
public class ComputerImp
{
            
    public static void fibimp(int param,String ID)
    {
        Enque enq=new Enque(param,ID);
        Thread t=new Thread(enq);
        t.start();
    }
    
    public static int fibRes(String ID)
    {
        try {
            Deque deq=new Deque(ID);
            FutureTask<String> f=new FutureTask<>(deq);
            f.run();
            return Integer.parseInt(f.get());
        } catch (InterruptedException | ExecutionException ex) {return 0;}
    }

}
