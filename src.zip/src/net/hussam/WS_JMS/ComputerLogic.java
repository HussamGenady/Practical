/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author hussam
 */
public class ComputerLogic implements MessageListener
{
    private QueueConnection qConnect = null;
    private QueueSession qSession = null;
    private Queue responseQ = null;
    private Queue requestQ = null;

    public ComputerLogic() 
    {
        try 
        {
            Properties env = new Properties();
            env.load(new FileInputStream("/home/hussam/wsq.properities"));
            Context ctx = new InitialContext(env);
            QueueConnectionFactory qFactory = (QueueConnectionFactory) ctx.lookup("fac");
            qConnect = qFactory.createQueueConnection();
            qSession = qConnect.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            requestQ = (Queue) ctx.lookup("req");
            responseQ = (Queue) ctx.lookup("res");
            qConnect.start();
            QueueReceiver Receiver = qSession.createReceiver(requestQ);
            Receiver.setMessageListener(this);
        } catch (JMSException | NamingException |IOException jmse) {}
    }
    
    private void Compute(int param,String ID)
    {
        try 
        {
            int res=param*2;
            QueueSender qSender = qSession.createSender(responseQ);
            TextMessage resmesg=qSession.createTextMessage();
            resmesg.setText(String.valueOf(res));
            resmesg.setStringProperty("ID", ID);
            qSender.send(resmesg);
        }
        catch (JMSException jmse){}
    }

    @Override
    public void onMessage(Message msg) 
    {
        try 
        {
            TextMessage message=(TextMessage) msg;
            System.out.println("new message received -> "+message.getText());
            Compute(Integer.parseInt(message.getText()),msg.getStringProperty("ID"));
        } 
        catch (JMSException ex) {}
    }
}
