/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author hussam
 */
public class Enque implements Runnable
{

    private QueueConnection qConnect ;
    private QueueSession qSession ;
    private Queue requestQ ;
    private final int param;
    private final String ID;
    
    public Enque(int param,String ID)
    {
        this.param=param;
        this.ID=ID;
    }
    
    private void sendRequest()
    {
        try 
        {
            Properties env = new Properties();
            env.load(new FileInputStream("/home/hussam/wsq.properities"));
            Context ctx = new InitialContext(env);
            QueueConnectionFactory qFactory = (QueueConnectionFactory) ctx.lookup("fac");
            qConnect = qFactory.createQueueConnection();
            qSession = qConnect.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            requestQ = (Queue) ctx.lookup("req");
            qConnect.start();
            TextMessage msg = qSession.createTextMessage();
            msg.setStringProperty("ID",ID);
            msg.setText(String.valueOf(param));
            QueueSender qSender = qSession.createSender(requestQ);
            qSender.send(msg);
        }
        catch (JMSException| NamingException |IOException jmse){}
    }
    
    @Override
    public void run() 
    {
        sendRequest();
    }
    
}
