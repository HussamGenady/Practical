/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.Callable;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author hussam
 */
public class Deque implements Callable<String>
{
    private QueueConnection qConnect ;
    private QueueSession qSession ;
    private Queue responseQ ;
    private final String ID;
    
    public Deque(String ID)
    {
        this.ID=ID;
    }
    
    private String ReceiveResponse()
    {
        try 
        {
            Properties env = new Properties();
            env.load(new FileInputStream("/home/hussam/wsq.properities"));
            Context ctx = new InitialContext(env);
            QueueConnectionFactory qFactory = (QueueConnectionFactory) ctx.lookup("fac");
            qConnect = qFactory.createQueueConnection();
            qSession = qConnect.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            responseQ = (Queue) ctx.lookup("res");
            qConnect.start();
            QueueReceiver qReceiver = qSession.createReceiver(responseQ,"ID='"+ID+"'");
            TextMessage receive = (TextMessage) qReceiver.receive();
            return receive.getText();
        }
        catch (JMSException| NamingException |IOException jmse){return null;}
    }

    @Override
    public String call() throws Exception {
        return ReceiveResponse();
    }
    
}
