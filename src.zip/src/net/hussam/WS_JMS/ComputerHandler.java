/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.WS_JMS;

import javax.jws.WebService;

/**
 *
 * @author hussam
 */

@WebService(endpointInterface = "net.hussam.WS_JMS.Computer")
public class ComputerHandler implements Computer
{
    private static final String ID = "HHAG";
    private static int Num;
    
    public ComputerHandler()
    {
        Num= 0;
    }
    @Override
    public  String Fib(int param) 
    {
        synchronized(this)
        {
            Num++;
        }
        ComputerImp.fibimp(param, ID+Num);
        return ID+Num;
    }

    @Override
    public int FibRes(String ID) 
    {
        return ComputerImp.fibRes(ID);
    }
    
}
