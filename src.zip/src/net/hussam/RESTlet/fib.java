/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RESTlet;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.restlet.Component;
import org.restlet.Request;
import org.restlet.Response;
import org.restlet.Restlet;
import org.restlet.data.MediaType;
import org.restlet.data.Method;
import org.restlet.data.Protocol;

/**
 *
 * @author hussam
 */
public class fib 
{

    public fib()
    {
        try 
        {
            Component component = new Component();
            component.getServers().add(Protocol.HTTP, 9090);
            Restlet handler = new RestletHandler(this);
            component.getDefaultHost().attach("/fib", handler);
            component.start();
        } 
        catch (Exception ex) 
        {}
    }

    private void doGet(Request req, Response res)
    {
        System.out.println("In doGet");
        String Name = req.getEntityAsText();
        res.setEntity("Hi "+ Name, MediaType.TEXT_PLAIN);
    }

    private void doPost(Request req, Response res) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void doDelete(Request req, Response res) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class RestletHandler extends Restlet 
    {
        private fib ob;
        public RestletHandler(fib obj)
        {
            ob=obj;
        }
        
        @Override
        public void handle(Request req, Response res) 
        {
            Method http_verb = req.getMethod();
            if (http_verb.equals(Method.GET)) {
                ob.doGet(req,res);
            } else if (http_verb.equals(Method.POST)) {
                ob.doPost(req,res);
            } else if (http_verb.equals(Method.DELETE)) {
                ob.doDelete(req,res);
            }
        }
    }
    
    public static void main(String[] args) {
        fib s=new fib();
    }
}

