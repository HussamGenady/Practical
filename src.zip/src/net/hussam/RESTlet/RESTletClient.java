/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RESTlet;

import org.restlet.Client;
import org.restlet.Request;
import org.restlet.Response;
import org.restlet.data.MediaType;
import org.restlet.data.Method;
import org.restlet.data.Protocol;

/**
 *
 * @author hussam
 */
public class RESTletClient 
{
    public RESTletClient()
    {
        Request request = new Request();
        request.setResourceRef("http://localhost:9090/fib");
        request.setMethod(Method.GET);
        request.setEntity("Hussam", MediaType.TEXT_PLAIN);
        Client client = new Client(Protocol.HTTP);
        Response response = client.handle(request);
        String entityAsText = response.getEntityAsText();
        System.out.println(entityAsText);
    }
    
    public static void main(String[] args) {
        RESTletClient c=new RESTletClient();
    }
}
