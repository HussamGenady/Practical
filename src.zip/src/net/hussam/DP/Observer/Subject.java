/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DP.Observer;

import java.util.Observable;

/**
 *
 * @author hussam
 */
public class Subject extends Observable implements Runnable
{
    private int Temp; 
      
    private void UpadteTemp()
    {
        if(Temp%2==0)
        {
            Temp+=100*Math.random();
        }
        else
        {
            Temp-=100*Math.random();
        }
        setChanged();
    }
    
    private synchronized void NotifyObs()
    {
        try 
        {
            while (true) 
            {                
                wait(3000);
                UpadteTemp();
                notifyObservers(Temp);
            }
        } 
        catch (InterruptedException ex) 
        {}
    }

    @Override
    public void run() {
        NotifyObs();
    }
}
