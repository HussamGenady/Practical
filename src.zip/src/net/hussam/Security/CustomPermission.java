/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Security;

import java.security.Permission;

/**
 *
 * @author hussam
 */
public class CustomPermission extends Permission {

    private final String Action;
    
    public CustomPermission()
    {
        super("");
        Action="";
    }
    
    public CustomPermission(String target,String Action)
    {
        super(target);
        this.Action=Action;
    }

    @Override
    public boolean implies(Permission other)
    {
        boolean Result=false;
        if(other !=null)
        {
            if (other instanceof CustomPermission) 
            {
                CustomPermission b = (CustomPermission) other;
                System.out.println(getActions());
                System.out.println(getName());
                if(b.getActions().split(",").length == 1)
                {
                    if(Action.contains("avoid"))
                    {
                        if(!getName().contains("porn"))
                        {
                            Result= true;
                        }
                    }
                    else
                    {
                        Result= true;
                    }
                }
            }
        }
       return Result;
    }

    @Override
    public boolean equals(Object obj)
    {
        boolean res=false;
        
        if(obj!=null)
        {
            if(obj.getClass()==this.getClass())
            {
                CustomPermission other=(CustomPermission) obj;
                if(other.getName().equals(getName()))
                {
                    if(other.Action.equals(Action))
                    {
                        res = true;
                    }
                }
            }
        }
        return res;
    }

    @Override
    public int hashCode() {
        return getName().hashCode()+Action.hashCode();
    }

    @Override
    public String getActions() {
        return Action;
    }

}
