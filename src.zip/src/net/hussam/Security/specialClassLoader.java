/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Security;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.hussam.InputOutput.InputOutput;

/**
 *
 * @author hussam
 */
public class specialClassLoader extends ClassLoader {

    private String className;
    private InputOutput io;

    public specialClassLoader(String className) {
        this.className = className;
        io = new InputOutput();
        LoadClass();
    }

    public void LoadClass() {
        try {
            try {
                Class<?> findClass = findClass(className);
                Method method = findClass.getMethod("main", String[].class);
                method.invoke(null, (Object) new String[]{});
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                Logger.getLogger(specialClassLoader.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (NoSuchMethodException | SecurityException | ClassNotFoundException ex) {
            Logger.getLogger(specialClassLoader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        byte[] classbytes = io.Read(name);
        Class<?> LoadedClass = defineClass("gen", classbytes, 0, classbytes.length);
        return LoadedClass;
    }

}
