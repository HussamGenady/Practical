/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Security;

import java.security.MessageDigest;
import net.hussam.InputOutput.InputOutput;

/**
 *
 * @author hussam
 */
public class Signature {

    private MessageDigest msgdgst;
    private InputOutput reader;

    public Signature() {
//        try {
//            msgdgst = MessageDigest.getInstance("SHA-1");
            reader = new InputOutput();
            byte[] hash = reader.Read("/home/hussam/HUSSAM.DSA");
//            msgdgst.update(reader.Read("/home/hussam/gen.java"));
//            byte[] hash = msgdgst.digest();
            String d = "";
            for (int i = 0; i < hash.length; i++)
            {
                int v = hash[i] & 0xFF;
                if (v < 16) 
                {
                    d += "0";											
                }
                d += Integer.toString(v, 16).toUpperCase() + "	";
            }
            System.out.println(d);
//        } catch (NoSuchAlgorithmException ex) {
//            Logger.getLogger(Signature.class.getName()).log(Level.SEVERE, null, ex);
//        }

    }

}
