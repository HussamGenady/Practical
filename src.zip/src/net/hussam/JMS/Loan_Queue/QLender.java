/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.JMS.Loan_Queue;

import java.io.*;
import java.util.Properties;
import javax.jms.*;
import javax.naming.*;

public class QLender //implements MessageListener 
{
    private QueueConnection qConnect = null;
    private QueueSession qSession = null; 
    private Queue requestQ = null;
    
    public QLender(String queuecf, String requestQueue) 
    {
        try 
        {
            Properties env = new Properties();
            env.load(new FileInputStream("/home/hussam/jndiqueue1.properities"));
            Context ctx = new InitialContext(env);
            QueueConnectionFactory qFactory = (QueueConnectionFactory)ctx.lookup(queuecf);
            qConnect = qFactory.createQueueConnection();
            qSession = qConnect.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            qConnect.start();
            requestQ = (Queue)ctx.lookup(requestQueue);
            QueueReceiver qReceiver = qSession.createReceiver(requestQ,"TRN='LOAN'");
            while(true)
            {
                Message receive = qReceiver.receive();
                onMessage(receive);
                //qReceiver.setMessageListener(this);
                //System.out.println("Waiting for loan requests...");
            }
        }
        catch (JMSException | NamingException |IOException jmse) {}
    }
            
    //@Override
    public void onMessage(Message message) 
    {
        try
        {
            boolean accepted = false;
            MapMessage msg = (MapMessage)message;
            double salary = msg.getDouble("Salary");
            double loanAmt = msg.getDouble("LoanAmount");
            // Determine whether to accept or decline the loan
            if (loanAmt < 200000) {
            accepted = (salary / loanAmt) > .25;
            } else {
            accepted = (salary / loanAmt) > .33;
            }
            System.out.println("" +
            "Percent = " + (salary / loanAmt) + ", loan is "
            + (accepted ? "Accepted!" : "Declined"));
            // Send the results back to the borrower
            TextMessage tmsg = qSession.createTextMessage();
            tmsg.setText(accepted ? "Accepted!" : "Declined");
            tmsg.setJMSCorrelationID(message.getJMSMessageID());
            // Create the sender and send the message
            QueueSender qSender =
            qSession.createSender((Queue)message.getJMSReplyTo());
            qSender.send(tmsg);
            System.out.println("\nWaiting for loan requests...");
        }
        catch (Exception jmse) {}
    }

    public static void main(String argv[]) 
    {  
        QLender lender = new QLender("factory", "req");
        try 
        {
            BufferedReader stdin = new BufferedReader
            (new InputStreamReader(System.in));
            System.out.println ("QLender application started");
            System.out.println ("Press enter to quit application");
            stdin.readLine();
        
        } catch (IOException ioe) {}
    }
}
