/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.JMS.Loan_Queue;

import java.io.*;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.jms.*;
import javax.naming.*;

public class QBorrower {

    private QueueConnection qConnect = null;
    private QueueSession qSession = null;
    private Queue responseQ = null;
    private Queue requestQ = null;

    public QBorrower(String queuecf, String requestQueue, String responseQueue) 
    {
        try 
        {
            Properties env = new Properties();
            env.load(new FileInputStream("/home/hussam/jndiqueue1.properities"));
            Context ctx = new InitialContext(env);
            QueueConnectionFactory qFactory = (QueueConnectionFactory) ctx.lookup(queuecf);
            qConnect = qFactory.createQueueConnection();
            qSession = qConnect.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            requestQ = (Queue) ctx.lookup(requestQueue);
            responseQ = (Queue) ctx.lookup(responseQueue);
            qConnect.start();
        } catch (JMSException | NamingException |IOException jmse) {}
    }
    
    private void sendLoanRequest(double salary, double loanAmt)
    {
        try 
        {
            MapMessage msg = qSession.createMapMessage();
            msg.setDouble("Salary", salary);
            msg.setDouble("LoanAmount", loanAmt);
            msg.setJMSReplyTo(responseQ);
            msg.setStringProperty("TRN", "DEP");
            QueueSender qSender = qSession.createSender(requestQ);
            qSender.send(msg);
            String filter =
            "JMSCorrelationID = '" + msg.getJMSMessageID() + "'";
            QueueReceiver qReceiver = qSession.createReceiver(responseQ, filter);
            TextMessage tmsg = (TextMessage)qReceiver.receive(30000);
            if (tmsg == null) {
            System.out.println("QLender not responding");
            } else {
            System.out.println("Loan request was " + tmsg.getText());
            }
        }
        catch (JMSException jmse){}
    }
    
    public static void main(String[] args)
    {
        QBorrower borrower=new QBorrower("factory", "req", "res");
        try 
        {
            BufferedReader stdin = new BufferedReader
            (new InputStreamReader(System.in));
            System.out.println ("QBorrower Application Started");
            System.out.println ("Press enter to quit application");
            System.out.println ("Enter: Salary, Loan_Amount");
            System.out.println("e.g. 50000, 120000");
            while (true) {
            System.out.print("> ");
            String loanRequest = stdin.readLine();
            if (loanRequest == null ||loanRequest.trim().length() <= 0) {
            }
            StringTokenizer st = new StringTokenizer(loanRequest, ",") ;
            double salary =Double.parseDouble(st.nextToken().trim());
            double loanAmt =Double.parseDouble(st.nextToken().trim());
            borrower.sendLoanRequest(salary, loanAmt);
            }
        }catch (IOException ioe){}
            
    }
}
