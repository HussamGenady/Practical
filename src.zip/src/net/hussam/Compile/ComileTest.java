/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Compile;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Locale;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/**
 *
 * @author hussam
 */
public class ComileTest 
{

    public ComileTest()
    {
        JavaCompiler cmplr=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector dign=new DiagnosticCollector();
        StandardJavaFileManager sjfm=cmplr.getStandardFileManager(dign, Locale.US, Charset.defaultCharset());
        ArrayList<String> fileNames=new ArrayList<>();
        fileNames.add("/home/hussam/gen.java");
        Iterable<JavaFileObject> jfo=(Iterable<JavaFileObject>) sjfm.getJavaFileObjectsFromStrings(fileNames);
        JavaCompiler.CompilationTask task = cmplr.getTask(null, null, dign, null, null,jfo );
        task.call();
    }
    
}
