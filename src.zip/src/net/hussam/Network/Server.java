/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Network;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import net.hussam.check.Employee;

/**
 *
 * @author hussam
 */
public class Server 
{
    private ServerSocket Serversocket;
    private Socket clientChannel;
    private InputStream requests;
    private OutputStream responses;
    private ObjectInputStream objIn;
    private ObjectOutputStream objOut;
    private Employee emp;

    public Server()
    {
        try {
            emp=new Employee();
            emp.setFirst_Name("Hussam");
            emp.setSecong_Name("Genady");
            emp.setAge(25);
            Serversocket=new ServerSocket(8089);
            clientChannel = Serversocket.accept();
            System.out.println("one user  connect");
            requests = clientChannel.getInputStream();
            responses= clientChannel.getOutputStream();
            objOut=new ObjectOutputStream(responses);
            objOut.writeObject(emp);
            responses.flush();
            objIn=new ObjectInputStream(requests);
             System.out.println(((Employee)objIn.readObject()).toString());
        } catch (IOException|ClassNotFoundException ex) {
            //ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        Server server=new Server();
    }
}
