/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Network;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author hussam
 */
public class Network 
{
    private URL url;
    private byte[] Data;
    private DataOutputStream dout;

    public Network() {
        try {
            url = new URL("http://afyzk.yt-downloader.org/download.php?id=c81a5a2b32cb77b6070741272c499253");
            
            InputStream inStream = url.openStream();
            inStream.read();
            int size =inStream.available();
            Data=new byte[size];
            for(int i=1;i<size;i++)
            {
                Data[i]=(byte)inStream.read();
            }
            dout=new DataOutputStream(new FileOutputStream("/home/hussam/file.mp3"));
            dout.write(Data);
        } catch (IOException ex) {

        }

    }
}
