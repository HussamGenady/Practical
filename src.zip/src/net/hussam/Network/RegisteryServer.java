/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author hussam
 */
public class RegisteryServer implements Runnable
{
    private ServerSocket Server;
    private ArrayList<Socket> Channels;

    public RegisteryServer(int Port)
    {
        try 
        {
            Server=new ServerSocket(Port);
            Channels=new ArrayList<>();  
        } catch (IOException ex) 
        {
        }
    }
    
    public ArrayList<Socket> getChannels() {
        return Channels;
    }

    @Override
    public void run() 
    {
       
        while (true) 
        {                
            try 
            {
                Channels.add(Server.accept());
            } catch (IOException ex) {}
        }
    }
}
