/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Network;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import net.hussam.check.Employee;

/**
 *
 * @author hussam
 */
public class Client  
{
    private Socket clientChannel;
    private InputStream responses;
    private OutputStream requests;
    private ObjectInputStream objIn;
    private ObjectOutputStream objOut;
    private Employee emp;
    
    public Client()
    {
        try {
            clientChannel = new Socket();
            clientChannel.connect(new InetSocketAddress("127.0.0.1", 8088));
            requests = clientChannel.getOutputStream();
            objOut=new ObjectOutputStream(requests);
            objOut.writeObject("Hello");
            requests.flush();
            responses = clientChannel.getInputStream();
            objIn=new ObjectInputStream(responses);
            System.out.println("New packet");
            System.out.println((String)objIn.readObject());
            clientChannel.close();
        } catch (IOException|ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Client client=new Client();
    }
}
