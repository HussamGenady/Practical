/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Network;

/**
 *
 * @author hussam
 */
public class RegServerTest 
{
    public static void main(String[] args) 
    {
        Handler h=new Handler();
        Thread t=new Thread(h);
        t.start();
    }
}
