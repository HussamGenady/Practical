/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 *
 * @author hussam
 */
public class Handler implements Runnable
{
    private RegisteryServer C1Reg;
    private RegisteryServer C2Reg;
    private InputStream S1In,S2In;
    private OutputStream S1out,S2out;
    
    public Handler()
    {
        C1Reg=new RegisteryServer(8089);
        Thread t=new Thread(C1Reg);
        t.start();
        C2Reg=new RegisteryServer(8088);
        Thread t1=new Thread(C2Reg);
        t1.start();
    }

    private void P2p(Socket s1, Socket s2) 
    {
        try 
        {
            S1In=s1.getInputStream();
            S2In=s2.getInputStream();
            S1out=s1.getOutputStream();
            S2out=s2.getOutputStream();
            S2out.write(S1In.read());
            S1out.write(S2In.read());
        } 
        catch (IOException ex) {}
    }

    @Override
    public void run() {
        if(C1Reg.getChannels().size()>=1&C2Reg.getChannels().size()>=1)
        {
            P2p(C1Reg.getChannels().get(0),C2Reg.getChannels().get(0));   
        }
    }
    
}
