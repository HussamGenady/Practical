/*
 * Employeeo change this license header, choose License Headers in Project Properties.
 * Employeeo change this template file, choose Employeeools | Employeeemplates
 * and open the template in the editor.
 */
package net.hussam.check;

/**
 *
 * @author hussam
 */
public class RawPair {
    
    private Employee first;
    private Employee second;

    public RawPair() {
        first = null;
        second = null;
    }

    public RawPair(Employee first, Employee second) {
        this.first = first;
        this.second = second;
    }

    public Employee getFirst() {
        return first;
    }

    public Employee getSecond() {
        return second;
    }

    public void setFirst(Employee newValue) {
        first = newValue;
    }

    public void setSecond(Employee newValue) {
        second = newValue;
    }
}
