/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.check;

import java.io.Serializable;

/**
 *
 * @author hussam
 */
public class FullName implements Serializable
{
    private String first_Name;
    private String secong_Name;
            
    public String getFirst_Name() {
        return first_Name;
    }

    public void setFirst_Name(String first_Name) {
        this.first_Name = first_Name;
    }

    public String getSecong_Name() {
        return secong_Name;
    }

    public void setSecong_Name(String secong_Name) {
        this.secong_Name = secong_Name;
    }
    
}
