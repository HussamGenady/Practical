/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.check;

import java.io.Serializable;
import java.rmi.Remote;

/**
 *
 * @author hussam
 */
public class Employee implements Comparable<Employee>, Runnable, Thread.UncaughtExceptionHandler ,Serializable,Remote{

    private FullName Fullname;
    private int age;
    private float salary;
    private float fines;
    private float bonus;
    private static final long serialVersionUID=-2241l;

    public Employee()
    {
        Fullname=new FullName();
    }

    public String getFirst_Name() {
        return Fullname.getFirst_Name();
    }

    public void setFirst_Name(String first_Name) {
        this.Fullname.setFirst_Name(first_Name);
    }

    public String getSecong_Name() {
        return Fullname.getSecong_Name();
    }

    public void setSecong_Name(String secong_Name) {
        this.Fullname.setSecong_Name(secong_Name); 
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getSalary()
    {
        return salary - fines + bonus;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    @Override
    public int compareTo(Employee o) {
        return this.age - (o.age);
    }

    @Override
    public void run() {
        getSalary();
    }

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        e.printStackTrace();
    }

    public float getFines() {
        return fines;
    }

    public void setFines(float fines) {
        this.fines = fines;
    }

    public float getBonus() {
        return bonus;
    }

    public void setBonus(float bonus) {
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        return "F_name = "+getFirst_Name()+"\nl_name = "+getSecong_Name()+"\nAge = "+getAge()+"\nSalary = "+getSalary();
    }
    
    public int TestMultiplication(int x,int y)
    {
        return x*y;
    }
}
