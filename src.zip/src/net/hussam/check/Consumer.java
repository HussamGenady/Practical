/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.check;

/**
 *
 * @author hussam
 */
public class Consumer implements Runnable
{
    private Ranner r;
    
    public Consumer(Ranner runner)
    {
        r=runner;
    }

    @Override
    public void run() {
        System.out.println("Salary = "+Float.toString(r.getSalary()));
    }
}
