/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.check;

/**
 *
 * @author hussam
 */
public class Producer implements Runnable
{
    private Ranner r;
    public static float Sal=1000;
    
    public Producer(Ranner runner)
    {
        r=runner;
    }
    
    @Override
    public void run() {
        r.SetSalary(Sal);
        Sal +=1000;
    }
    
}
