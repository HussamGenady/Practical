/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.check;

/**
 *
 * @author hussam
 */
public class Task {

    public Pair<? extends Employee> getPair() {
        return pair;
    }

    public void setPair(Pair<? extends Employee> pair) {
        this.pair = pair;
    }
    
    private Pair<? extends Employee> pair;

    public Task() 
    {
        pair=new Pair<>();
    }

    public static void printRawBuddies(RawPair p) {
        Employee first = (Employee) p.getFirst();
        Employee second = (Employee) p.getSecond();
        System.out.println(first.getFirst_Name() + " and " + second.getFirst_Name() + " are buddies.");
    }

    public void printBuddies() 
    {
        Employee first = pair.getFirst();
        Employee second = pair.getSecond();
        System.out.println(first.getFirst_Name() + " and " + second.getFirst_Name() + " are buddies.");
    }
}
