/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.check;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 *
 * @author hussam
 */
public class Ranner 
{
    private BlockingQueue<Employee> e;
    private Employee emp;
    
    public Ranner()
    {
        try {
            emp =new Employee();
            e=new ArrayBlockingQueue<>(1);
            e.put(emp);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
    
    public void SetSalary(float salary)
    {
        try {
            e.take().setSalary(salary);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    public float getSalary()
    {
        try {
            return e.take().getSalary();
        } catch (InterruptedException ex) {
           ex.printStackTrace();
           return 0;
        }
    }
    
}
