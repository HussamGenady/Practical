/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hussam
 */
public class TestDB
{
    public TestDB()
    {
        try 
        {
            Connection connection = DriverManager.getConnection("jdbc:jtds:sqlserver://127.0.0.1:1515/DB-NAME");
            Statement createStatement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE );/*Check types*/
            ResultSet executeQuery = createStatement.executeQuery("");
            while (executeQuery.next())
            {
                executeQuery.getString(0);
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(TestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
