/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DetailedSOAPWS;

import java.io.IOException;
import javax.xml.ws.WebFault;

/**
 *
 * @author hussam
 */
@WebFault(messageName = "fibException" , targetNamespace = "http://DetailedSOAPWS.hussam.net/")
public class fibException extends IOException 
{
    private final String details;
   
    public fibException(String reason, String details) 
    {
        super(reason);
        this.details = details;
    }
    
    public String getFaultInfo() {
        return details;
    }
}
