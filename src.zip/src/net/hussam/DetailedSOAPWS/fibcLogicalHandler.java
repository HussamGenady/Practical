/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DetailedSOAPWS;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.ws.LogicalMessage;
import javax.xml.ws.handler.LogicalHandler;
import javax.xml.ws.handler.LogicalMessageContext;
import javax.xml.ws.handler.MessageContext;

/**
 *
 * @author hussam
 */
public class fibcLogicalHandler implements LogicalHandler<LogicalMessageContext>
{

    @Override
    public boolean handleMessage(LogicalMessageContext context)
    {
        if(!(Boolean)context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY))
        {
            System.out.println("Res...");
            try 
            {
                LogicalMessage message = context.getMessage();
                JAXBContext xmlBinding = JAXBContext.newInstance("net.hussam.DetailedSOAPWS");
                JAXBElement payload = (JAXBElement)message.getPayload(xmlBinding);
                FibcResponse value = (FibcResponse)payload.getValue();
                int arg0 = value.getReturn();
                System.out.println(arg0);
//                if(arg0 < 0 )
//                {
//                    value.setArg0(0);
//                    payload.setValue(value);
//                    message.setPayload(payload,xmlBinding);
//                }

            } catch (JAXBException ex) 
            {
                ex.printStackTrace();
            }
        }
        return true;
    }

    @Override
    public boolean handleFault(LogicalMessageContext context) {
        System.out.println("in Fault");
        return true;
    }

    @Override
    public void close(MessageContext context) {
        System.out.println("in close");
    }
    
}
