/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DetailedSOAPWS;

import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.jws.HandlerChain;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

/**
 *
 * @author hussam
 */

@HandlerChain(file = "handlerConfig.xml")
public class fibcConsumer 
{
    private Service service;
    private URL   wsdlLocation;
    private QName serviceName;
    
    public fibcConsumer()
    {
        try 
        {
            wsdlLocation =new URL("http://127.0.0.1:9090/fibc");
            serviceName = new QName("http://DetailedSOAPWS.hussam.net/","fibImpService");
            service = Service.create(wsdlLocation, serviceName);
            service.setHandlerResolver(new ServiceHandlerResolver());
            fib port = service.getPort(net.hussam.DetailedSOAPWS.fib.class);
            Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
            for (String key : requestContext.keySet()) {
                System.out.println("Value of "+key+" => "+requestContext.get(key));
            }
            
            String fibc = port.fibc(99);
            
            Map<String, Object> responseContext = ((BindingProvider)port).getResponseContext();
            for (String key : responseContext.keySet()) {
                System.out.println("Value of "+key+" => "+responseContext.get(key));
            }
            
            System.out.println("Result = "+fibc);
        } catch (IOException ex) {}
        
    }

    public static void main(String[] args)
    {
        fibcConsumer Client = new fibcConsumer();
    }

    private static class ServiceHandlerResolver implements HandlerResolver{

        @Override
        public List<Handler> getHandlerChain(PortInfo portInfo)
        {
            ArrayList<Handler> chain=new ArrayList<>();
            chain.add(new fibcSOAPHanhler());
            return chain;
        }
    }
    
}
