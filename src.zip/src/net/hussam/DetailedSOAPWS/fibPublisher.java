/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DetailedSOAPWS;

import javax.xml.ws.Binding;
import javax.xml.ws.Endpoint;
import javax.xml.ws.soap.SOAPBinding;

/**
 *
 * @author hussam
 */
public class fibPublisher 
{
    private final fibImp impObj;
    
    /**
     *
     */
    public fibPublisher()
    {
        impObj = new fibImp();
        Endpoint publish = Endpoint.create(impObj);
        SOAPBinding binding = (SOAPBinding) publish.getBinding();
        binding.setMTOMEnabled(true);
        publish.publish("http://127.0.0.1:9090/fibc");
    }
    
    public static void main(String[] args) {
        fibPublisher p=new fibPublisher();
    }
}
