/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DetailedSOAPWS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.jws.HandlerChain;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.Service;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.PortInfo;
import javax.xml.ws.soap.SOAPBinding;

/**
 *
 * @author hussam
 */
@WebService(endpointInterface = "net.hussam.DetailedSOAPWS.fib")
@HandlerChain(file = "handlerConfig.xml")
@BindingType(value = SOAPBinding.SOAP12HTTP_MTOM_BINDING)
public class fibImp implements fib
{
    @Resource
    WebServiceContext ws_cntx;
    
    @Override
    public String fibc(int Rabbitscount) throws IOException
    {
        if(Rabbitscount < 0)
        {
            throw new IOException("Negative args not allowed.");
        }
        MessageContext messageContext = ws_cntx.getMessageContext();
        
        for (String Key : messageContext.keySet()) 
        {
            System.out.println("Value of "+Key+" ==> "+messageContext.get(Key));
        }
        
        return String.valueOf(Rabbitscount);
    }
   
    private static class ServiceHandlerResolver implements HandlerResolver{

        @Override
        public List<Handler> getHandlerChain(PortInfo portInfo)
        {
            ArrayList<Handler> chain=new ArrayList<>();
            chain.add(new fibcSOAPHanhler());
            return chain;
        }
    }
    
}
