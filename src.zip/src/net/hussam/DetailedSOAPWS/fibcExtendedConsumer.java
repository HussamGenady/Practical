/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.DetailedSOAPWS;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javax.jws.HandlerChain;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hussam
 */


@HandlerChain(file = "handlerConfig.xml")
public class fibcExtendedConsumer extends Service 
{
    
    public fibcExtendedConsumer() throws MalformedURLException
    {
        super(new URL("http://127.0.0.1:9090/fibc"),new QName("http://DetailedSOAPWS.hussam.net/","fibImpService"));
    }
    
    public static void main(String[] args) {
        try {
            fibcExtendedConsumer c = new fibcExtendedConsumer();
            System.out.println(c.getPort(net.hussam.DetailedSOAPWS.fib.class).fibc(5));
        } catch (IOException ex) {}
    }

}
