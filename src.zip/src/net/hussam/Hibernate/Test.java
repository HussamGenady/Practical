/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Hibernate;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author hussam
 */
public class Test 
{
    public static void main(String[] args)
    {
        SessionFactory sessionFactory = new Configuration().configure(new File("/home/hussam/hibernate.cfg.xml")).buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Item itm=new Item();
        itm.setName("Pen");
        Example ex=Example.create(itm);
        ex.enableLike(MatchMode.ANYWHERE);
        ex.ignoreCase();
        Criteria Cri = session.createCriteria(Item.class);
        Cri.add(ex);
        List list1 = Cri.list();
        for (Iterator iterator = list1.iterator(); iterator.hasNext();) {
            Item next = (Item) iterator.next();
            System.out.println(next.getId());
            System.out.println(next.getName());
            for (Iterator iterator1 = next.getBids().iterator(); iterator1.hasNext();) {
                Bid next1 = (Bid) iterator1.next();
                System.out.println(next1.getDescription());
            }
        }
        session.getTransaction().commit();
        session.close();
        System.out.println("Done");
    }
}
