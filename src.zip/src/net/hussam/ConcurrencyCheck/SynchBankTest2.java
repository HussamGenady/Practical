package net.hussam.ConcurrencyCheck;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This program shows how multiple threads can safely access a data structure, using synchronized
 * methods.
 * @version 1.30 2004-08-01
 * @author Cay Horstmann
 */
public class SynchBankTest2
{
    public static final int NACCOUNTS = 10;
    public static final double INITIAL_BALANCE = 100;
    
    public static void main(String[] args)
    {
       Bank b = new Bank(NACCOUNTS, INITIAL_BALANCE);
       ExecutorService excutor=Executors.newFixedThreadPool(5);
       
       for (int i = 0; i < NACCOUNTS; i++)
       {
          TransferRunnable r = new TransferRunnable(b, i, INITIAL_BALANCE);
          Future<Integer> tsk=excutor.submit(r);
       }
       excutor.shutdown();
   }
}
