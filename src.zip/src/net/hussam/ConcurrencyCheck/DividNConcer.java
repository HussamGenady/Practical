/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.ConcurrencyCheck;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RecursiveTask;

/**
 *
 * @author hussam
 */
public class DividNConcer extends RecursiveTask<ArrayList<Integer>>
{

    private ArrayList<Integer> list;
    
    public DividNConcer(ArrayList<Integer> list)
    {
        this.list = list;
    }
    
    @Override
    protected ArrayList<Integer> compute()
    {
        if(list.size()==1)
        {
            return list;
        }
        else
        {
            DividNConcer DnC1=new DividNConcer((ArrayList<Integer>)list.subList(0, list.size()/2));
            DividNConcer DnC2=new DividNConcer((ArrayList<Integer>)list.subList(list.size()/2,list.size()));
            invokeAll(DnC1,DnC2);
            ArrayList<Integer> result=new ArrayList<>();
            if(DnC1.join().get(0) < DnC2.join().get(0))
            {
                result.addAll(DnC1.join());
                result.addAll(DnC2.join());
            }
            else
            {
                result.addAll(DnC2.join());
                result.addAll(DnC1.join());
            }
            return result;
        }
        
    }
    
}
