/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Natives;

import com.sun.glass.utils.NativeLibLoader;

/**
 *
 * @author hussam
 */
public class HelloNativeTest {
///add package to class name to work
    static {
        System.setProperty("java.library.path", "/home/hussam/Native");
        System.loadLibrary("HelloNative");
        
    }
    public static void main(String[] args) {
        HelloNative.greeting();
    }
}
