/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Script;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineFactory;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 *
 * @author hussam
 */
public class Scripting 
{
    private final ScriptEngineManager Manager;
    private ScriptEngine Engine;
    
    public Scripting()
    {
        Manager=new ScriptEngineManager();
        Engine =Manager.getEngineByName("ruby");
    }
    
    public String Execute(String script) throws ScriptException
    {
        String eval = (String) Engine.eval(script);
        return eval;
    }
}
