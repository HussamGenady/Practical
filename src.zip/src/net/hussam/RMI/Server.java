/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package net.hussam.RMI;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

/**
 *
 * @author hussam
 */
public class Server 
{
    private TimeTellerSupporter teller;
  
    public Server()
    {
        try 
        {
            teller=new TimeTellerSupporter();
            //LocateRegistry.createRegistry(54333);  
//            System.setProperty("java.rmi.server.codebase", "//197.40.146.60:54322/updater");
              Naming.bind("//127.0.0.1:54333/updater", teller);
        }
        catch (Exception ex){}
        
    }
    public static void main(String[] args) {
        Server server=new Server();
    }
    
}
