/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RMI;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import net.hussam.check.Employee;

/**
 *
 * @author hussam
 */
public class TimeTellerSupporter extends UnicastRemoteObject implements TimeTeller
{
    
    public TimeTellerSupporter() throws RemoteException
    {
      
    }

    @Override
    public void UpdateEmployee(Employee emp) throws RemoteException {
        emp.setFirst_Name("hussam");
        System.out.println(emp.toString());
    }
    
}
