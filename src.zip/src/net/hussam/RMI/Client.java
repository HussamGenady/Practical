/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RMI;

import java.rmi.Naming;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.hussam.check.Employee;

/**
 *
 * @author hussam
 */
public class Client 
{
    private TimeTeller teller;
    private Employee emp;
    
    public Client()
    {
        try
        {
            emp=new Employee();
            TimeTeller teller = (TimeTeller) Naming.lookup("//hussam.net:54333/updater");
            teller.UpdateEmployee(emp);
            JOptionPane.showMessageDialog(null, emp.toString());
        } catch (Exception ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {
        Client client=new Client();
    }
}
