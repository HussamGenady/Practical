/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.EasyMockAnnotations;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

// @RunWith attaches a runner with the test class to initialize the test data
@RunWith(EasyMockRunner.class)
public class MathApplicationTester {

    // @TestSubject annotation is used to identify class which is going to use the mock object
    @TestSubject
    MathApplication mathApplication = new MathApplication();

    // @Mock annotation is used to create the mock object to be injected
    @Mock
    CalculatorService calcService;

    public void createMock() {
        //add the behavior of calc service to add two numbers
        EasyMock.expect(calcService.add(10.0,20.0)).andReturn(30.0);
        EasyMock.expectLastCall().times(1);
        
        calcService.serviceUsed();
        EasyMock.expectLastCall().times(2);
        
        

        //activate the mock
        EasyMock.replay(calcService);
    }

    @Test
    public void testAdd() {
        createMock();
        //test the add functionality
        Assert.assertEquals(mathApplication.add(10.0, 20.0), 30.0, 0);
   
        //verify call to calcService is made or not
        EasyMock.verify(calcService);
    }
}
