/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RuntimeAnnotation;

import net.hussam.RuntimeAnnotation.ActionPerformedForInstaller;
import net.hussam.RuntimeAnnotation.ActionPerformedFor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author hussam
 */
public class AnnotationTest extends JFrame{
    
    public JButton button;
    public AnnotationTest()
    {
        button=new JButton("Button");
        ActionPerformedForInstaller.Installer(this);
        add(button);
    }
    @ActionPerformedFor(source = "button") public void doSomething()
    {
        JOptionPane.showMessageDialog(null, "Hello in Annotation");
    }

}
