/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RuntimeAnnotation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;

/**
 *
 * @author hussam
 */
public class ActionPerformedForInstaller 
{
    
    

    public ActionPerformedForInstaller()
    {
        
    }
    
    public static void Installer(Object obj)
    {
        Class cls=  obj.getClass();
        
        for (Method method : cls.getDeclaredMethods()) 
        {
            try 
            {
                ActionPerformedFor annotation = method.getAnnotation(ActionPerformedFor.class);
                if(annotation!=null)
                {
                    Field field = cls.getDeclaredField(annotation.source());
                    field.setAccessible(true);
                    JButton button=(JButton) field.get(obj);
                    button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                Object invoke = method.invoke(obj, (Object[]) null);
                            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                                Logger.getLogger(ActionPerformedForInstaller.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    });
                }
            } catch (Exception ex) {
                Logger.getLogger(ActionPerformedForInstaller.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
