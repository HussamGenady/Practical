/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RuntimeAnnotation;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author hussam
 */
public class AnnotationItemTest 
{
    public @Reader("/home/hussam/gen.java") InputStreamReader reader;
    
    public AnnotationItemTest()
    {
         try
        {
            char[] Data=new char[200];
            ReaderInstaller.ProcessReader(this);
            reader.read(Data);
            JOptionPane.showMessageDialog(null,new String(Data).trim());
        } catch (IOException ex) {
            Logger.getLogger(AnnotationItemTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
