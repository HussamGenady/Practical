/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.RuntimeAnnotation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.lang.annotation.Documented;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hussam
 */

public class ReaderInstaller {

    public static void ProcessReader(Object obj) 
    {
        Class cls = obj.getClass();
        for (Field field : cls.getFields())
        {
            Reader annotation = field.getAnnotation(Reader.class);
            if (annotation != null) {
                try 
                {
                    field.set(obj, new InputStreamReader(new FileInputStream(annotation.value()),Charset.forName("utf8")));
                } catch (IllegalArgumentException | IllegalAccessException | FileNotFoundException ex) {
                    Logger.getLogger(ReaderInstaller.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
