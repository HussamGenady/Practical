/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Proxy;

import java.lang.reflect.Proxy;

/**
 *
 * @author hussam
 */
public class CalcProxy implements Calculator{
    private CalcProxyHandler handler;
    Calculator clc;
    public CalcProxy()
    {
        handler=new CalcProxyHandler();
        clc=(Calculator) Proxy.newProxyInstance(Calculator.class.getClassLoader(),new Class[] {Calculator.class},handler );
    }

    @Override
    public double Sum(int x, int y) {
        return clc.Sum(x, y);
    }

    @Override
    public double Sub(int x, int y) {
        return clc.Sub(x, y);
    }

    @Override
    public double Divid(int x, int y) {
        return clc.Divid(x, y);
    }

    @Override
    public double Multiply(int x, int y) {
        return clc.Multiply(x, y);
    }
}
