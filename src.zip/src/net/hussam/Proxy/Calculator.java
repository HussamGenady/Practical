/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Proxy;

/**
 *
 * @author hussam
 */
public interface Calculator 
{
    public double Sum(int x,int y);
    public double Sub(int x,int y);
    public double Divid(int x,int y);
    public double Multiply(int x,int y);
}
