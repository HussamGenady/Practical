/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Proxy;

/**
 *
 * @author hussam
 */
public class CalcImp implements Calculator{

    @Override
    public double Sum(int x, int y) {
       return x+y;
    }

    @Override
    public double Sub(int x, int y) {
        return x-y;
    }

    @Override
    public double Divid(int x, int y) {
        return x*y;
    }

    @Override
    public double Multiply(int x, int y) {
        return x/y;
    }
    
}
