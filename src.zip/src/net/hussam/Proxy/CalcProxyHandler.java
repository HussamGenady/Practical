/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.Proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

/**
 *
 * @author hussam
 */
public class CalcProxyHandler implements InvocationHandler{
    private final CalcImp calc;
    
    public CalcProxyHandler()
    {
        calc=new CalcImp();
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable 
    {
        switch(method.getName())
        {
            case "Sum":
            {
                return calc.Sum(Integer.parseInt(args[0].toString()),Integer.parseInt(args[1].toString()));
            }
            case "Sub":
            {
                return calc.Sub(Integer.parseInt(args[0].toString()),Integer.parseInt(args[1].toString()));
            }
            default:
            {
                return calc.Multiply(Integer.parseInt(args[0].toString()),Integer.parseInt(args[1].toString()));
            }
        }
    }
    
}
