/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.InputOutput;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import net.hussam.check.Employee;

/**
 *
 * @author hussam
 */
public class writer 
{
 
    private FileOutputStream fout;
    private ObjectOutputStream objOut;
    private Employee e;
    
    public writer()
    {
        try
        {
            fout =new FileOutputStream("/home/hussam/objs.txt");
            objOut=new ObjectOutputStream(fout);
            e=new Employee();
            e.setAge(25);
            e.setFirst_Name("Hussam");
            e.setSalary(5000);
            e.setSecong_Name("Genady");
            objOut.writeObject(e);
            objOut.flush();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }

    }
}
