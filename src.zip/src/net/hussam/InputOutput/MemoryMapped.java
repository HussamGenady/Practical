/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.InputOutput;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;

/**
 *
 * @author hussam
 */
public class MemoryMapped {

    public MemoryMapped() {
        try {
            
            FileChannel fc = FileChannel.open(Paths.get("/home/hussam/gen.java"), StandardOpenOption.READ,StandardOpenOption.WRITE
            );
            FileLock lock=fc.lock();
            ByteBuffer bb = fc.map(FileChannel.MapMode.READ_WRITE, 0, fc.size());
            byte[] dst=new byte[bb.limit()];
            Calendar c = Calendar.getInstance();
            bb.get(dst);
            String s=new String(dst, Charset.forName("utf8"));
            Calendar c1 = Calendar.getInstance();
            System.out.println(s);
            System.out.println(c1.getTime().getTime() - c.getTime().getTime());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
