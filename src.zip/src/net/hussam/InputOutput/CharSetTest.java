/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.InputOutput;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;

/**
 *
 * @author hussam
 */
public class CharSetTest 
{
    
    private File file;
    private FileInputStream fin;
    private FileOutputStream fout;
    private byte b[];
    private Charset chrst;
    private ByteBuffer bb;
    
    public CharSetTest()
    {
        file=new File("/home/hussam/gen1.java");
        chrst=Charset.forName("utf-32");
    }
    
    public void decode()
    {
        try
        {
            
            b=new byte[(int)file.length()];
            fin = new FileInputStream(file);
            fin.read(b);
            bb=ByteBuffer.wrap(b);
            CharBuffer decode = chrst.decode(bb);
            System.out.println(decode.toString());
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }

    public void encode()
    {
        try
        {
            String s="Heya";
            bb=chrst.encode(s);
            fout=new FileOutputStream(file);
            fout.write(bb.array());
            fout.flush();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
}
