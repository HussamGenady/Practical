/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.InputOutput;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import net.hussam.check.Employee;

/**
 *
 * @author hussam
 */
public class Reader
{
    private FileInputStream fin;
    private ObjectInputStream objin;
    private Employee e;
    
    public Reader()
    {
        try
        {
            fin=new FileInputStream("/home/hussam/objs.txt");
            objin=new ObjectInputStream(fin);
            e=(Employee) objin.readObject();
            System.out.println(e.toString());
        }
        catch(IOException | ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
    }
}
