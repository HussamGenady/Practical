/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.InputOutput;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 *
 * @author hussam
 */
public class InputOutput
{
    private FileInputStream fin;
//    private InputStreamReader Inr;
//    private FileReader fr;
    private File file;
//    private FileOutputStream fout;
//    private OutputStreamWriter writer;
    
    public byte[] Read(String fileName)
    {
         byte[] arry=null;
        try 
        {
            file=new File(fileName);
            fin=new FileInputStream(file);
            arry=new byte[(int)file.length()];
            fin.read(arry);
//            System.out.println(String.copyValueOf(arry));
//            Calendar c1 = Calendar.getInstance();
//            System.out.println(c1.getTime().getTime() - c.getTime().getTime());
//            System.out.println();
        } catch (IOException ex) {
        }
        finally
        {
            return arry;
        }
    }
    
//    public void Write()
//    {
//        try
//        {
//            file=new File("/home/hussam/w1.txt");
//            fout=new FileOutputStream(file);
//            writer=new OutputStreamWriter(fout);
//            writer.write("Helloooooo");
//            writer.flush();
//        }
//        catch(IOException ex)
//        {
//            ex.printStackTrace();
//        }
//    }
}
