/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.JMX;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;
import com.sun.jdmk.comm.*;

/**
 *
 * @author hussam
 */
public class HelloAgent
{
    private MBeanServer mbs = null;

    public HelloAgent()
    {
        try {
            mbs = MBeanServerFactory.createMBeanServer( "HiAgent" );
            HtmlAdaptorServer adapter = new HtmlAdaptorServer();
            HelloWorld hw = new HelloWorld();
            ObjectName adapterName = null;
            ObjectName helloWorldName = null;
            helloWorldName = new ObjectName( "HiAgent:name=hiWorld1" );
            mbs.registerMBean( hw, helloWorldName );
            adapterName = new ObjectName( "HeiAgent:name=htmladapter,port=9092" );
            adapter.setPort( 9092 );
            mbs.registerMBean( adapter, adapterName );
            adapter.start();
        } catch (MalformedObjectNameException|InstanceAlreadyExistsException|MBeanRegistrationException|NotCompliantMBeanException ex) {}
    }
    
    public static void main( String args[] )
    {
        System.out.println( "HelloAgent is running" );
        HelloAgent agent = new HelloAgent();
    }
    
}