/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.JMX;

/**
 *
 * @author hussam
 */
public class HelloWorld implements HelloWorldMBean
{
    private String Greeting;
    
    public HelloWorld()
    {
        Greeting="";
    }

    @Override
    public void setGreeting(String greeting) {
        Greeting=greeting;
    }

    @Override
    public String getGreeting() {
        return Greeting;
    }

    @Override
    public void printGreeting() {
        System.out.println(Greeting);
    }
    
}
