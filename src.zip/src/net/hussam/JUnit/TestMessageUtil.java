/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.JUnit;

import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author genady
 */
public class TestMessageUtil
{
    @Test
    public void TestSalutation()
    {
        String msg="Hussam";
        MessageUtil msgutl=new MessageUtil(msg);
        Assert.assertEquals("Hi!"+msg ,msgutl.Salutation());
    }
}
