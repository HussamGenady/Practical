/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.hussam.JUnit;

/**
 *
 * @author genady
 */
class MessageUtil 
{

    String msg;
    
    public MessageUtil(String msg)
    {
        this.msg=msg;
    }
    
    public String Salutation()
    {
        System.out.println("Hi "+msg);
        return "Hi "+msg;
    }
    
}
